const {
    addAvailability,
    getAllAvailability,
    getAvailabilityByDoctor,
    getDoctorByUserId,
    getAvailabilityById,
    updateAvailability,
    deleteAvailability
} = require("../models/availabilityModel");


// =====================================================
// ADD AVAILABILITY
// =====================================================

const createAvailability = async (req, res) => {
    try {
        const {
            doctor_id,
            day_of_week,
            start_time,
            end_time
        } = req.body;

        // Basic validation
        if (
            !day_of_week ||
            !start_time ||
            !end_time
        ) {
            return res.status(400).json({
                success: false,
                message: "Day, start time and end time are required"
            });
        }

        // End time must be after start time
        if (start_time >= end_time) {
            return res.status(400).json({
                success: false,
                message: "End time must be after start time"
            });
        }

        let finalDoctorId;

        // Admin can create availability for any doctor
        if (req.user.role === "admin") {

            if (!doctor_id) {
                return res.status(400).json({
                    success: false,
                    message: "doctor_id is required for admin"
                });
            }

            finalDoctorId = doctor_id;

        } else {

            // Doctor can only create availability for themselves
            const doctor = await getDoctorByUserId(req.user.id);

            if (!doctor) {
                return res.status(404).json({
                    success: false,
                    message: "Doctor profile not found"
                });
            }

            finalDoctorId = doctor.doctor_id;
        }

        const availabilityId = await addAvailability({
            doctor_id: finalDoctorId,
            day_of_week,
            start_time,
            end_time
        });

        res.status(201).json({
            success: true,
            message: "Availability added successfully",
            availabilityId
        });

    } catch (err) {

        console.error("Create availability error:", err);

        res.status(500).json({
            success: false,
            message: err.message
        });
    }
};


// =====================================================
// GET ALL AVAILABILITY
// =====================================================

const getAvailability = async (req, res) => {
    try {

        const availability = await getAllAvailability();

        res.status(200).json({
            success: true,
            count: availability.length,
            availability
        });

    } catch (err) {

        console.error("Get availability error:", err);

        res.status(500).json({
            success: false,
            message: err.message
        });
    }
};


// =====================================================
// GET AVAILABILITY BY DOCTOR
// =====================================================

const getDoctorAvailability = async (req, res) => {
    try {

        const { doctorId } = req.params;

        const availability = await getAvailabilityByDoctor(doctorId);

        res.status(200).json({
            success: true,
            count: availability.length,
            availability
        });

    } catch (err) {

        console.error("Get doctor availability error:", err);

        res.status(500).json({
            success: false,
            message: err.message
        });
    }
};


// =====================================================
// UPDATE AVAILABILITY
// =====================================================

const editAvailability = async (req, res) => {
    try {

        const { id } = req.params;

        const {
            day_of_week,
            start_time,
            end_time
        } = req.body;

        if (
            !day_of_week ||
            !start_time ||
            !end_time
        ) {
            return res.status(400).json({
                success: false,
                message: "Day, start time and end time are required"
            });
        }

        if (start_time >= end_time) {
            return res.status(400).json({
                success: false,
                message: "End time must be after start time"
            });
        }

        // Find availability record
        const existingAvailability =
            await getAvailabilityById(id);

        if (!existingAvailability) {
            return res.status(404).json({
                success: false,
                message: "Availability not found"
            });
        }

        // Doctor can update only their own availability
        if (req.user.role === "doctor") {

            if (
                existingAvailability.user_id !== req.user.id
            ) {
                return res.status(403).json({
                    success: false,
                    message: "You can only update your own availability"
                });
            }
        }

        await updateAvailability(id, {
            day_of_week,
            start_time,
            end_time
        });

        res.status(200).json({
            success: true,
            message: "Availability updated successfully"
        });

    } catch (err) {

        console.error("Update availability error:", err);

        res.status(500).json({
            success: false,
            message: err.message
        });
    }
};


// =====================================================
// DELETE AVAILABILITY
// =====================================================

const removeAvailability = async (req, res) => {
    try {

        const { id } = req.params;

        const existingAvailability =
            await getAvailabilityById(id);

        if (!existingAvailability) {
            return res.status(404).json({
                success: false,
                message: "Availability not found"
            });
        }

        // Doctor can delete only their own availability
        if (req.user.role === "doctor") {

            if (
                existingAvailability.user_id !== req.user.id
            ) {
                return res.status(403).json({
                    success: false,
                    message: "You can only delete your own availability"
                });
            }
        }

        await deleteAvailability(id);

        res.status(200).json({
            success: true,
            message: "Availability deleted successfully"
        });

    } catch (err) {

        console.error("Delete availability error:", err);

        res.status(500).json({
            success: false,
            message: err.message
        });
    }
};


module.exports = {
    createAvailability,
    getAvailability,
    getDoctorAvailability,
    editAvailability,
    removeAvailability
};