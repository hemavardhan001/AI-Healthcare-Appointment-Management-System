const {
    createAppointment,
    checkDoctorAvailability,
    checkSlotAvailability,
    getAllAppointments,
    getPatientAppointments,
    getDoctorAppointments,
    getAppointmentById,
    updateAppointment,
    deleteAppointment
} = require("../models/appointmentModel");

// =======================================
// BOOK APPOINTMENT
// Patient only
// =======================================

const bookAppointment = async (req, res) => {
    try {
        const {
            doctor_id,
            appointment_date,
            start_time,
            end_time,
            notes
        } = req.body;

        const patient_id = req.user.id;

        // Required fields
        if (
            !doctor_id ||
            !appointment_date ||
            !start_time ||
            !end_time
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Doctor, date, start time and end time are required."
            });
        }

        // Validate date
        const today = new Date();

        today.setHours(
            0,
            0,
            0,
            0
        );

        const bookingDate = new Date(
            `${appointment_date}T00:00:00`
        );

        if (
            Number.isNaN(
                bookingDate.getTime()
            )
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid appointment date."
            });
        }

        if (bookingDate < today) {
            return res.status(400).json({
                success: false,
                message:
                    "Cannot book an appointment in the past."
            });
        }

        // Validate time
        if (start_time >= end_time) {
            return res.status(400).json({
                success: false,
                message:
                    "End time must be after start time."
            });
        }

        // Check slot availability
        const existing =
            await checkSlotAvailability(
                doctor_id,
                appointment_date,
                start_time,
                end_time
            );

        if (existing) {
            return res.status(400).json({
                success: false,
                message:
                    "Doctor already has an appointment during this time slot."
            });
        }

        // Create appointment
        const appointmentId =
            await createAppointment({
                patient_id,
                doctor_id,
                appointment_date,
                start_time,
                end_time,
                status: "scheduled",
                notes: notes || null
            });

        return res.status(201).json({
            success: true,
            message:
                "Appointment booked successfully.",
            appointmentId
        });

    } catch (err) {
        console.error(
            "Book Appointment Error:",
            err
        );

        return res.status(500).json({
            success: false,
            message:
                "Internal Server Error"
        });
    }
};


// =======================================
// GET ALL APPOINTMENTS
// Admin only
// =======================================

const getAppointments = async (req, res) => {
    try {
        const appointments =
            await getAllAppointments();

        return res.status(200).json({
            success: true,
            count: appointments.length,
            appointments
        });

    } catch (err) {
        console.error(
            "Get All Appointments Error:",
            err
        );

        return res.status(500).json({
            success: false,
            message:
                "Internal Server Error"
        });
    }
};


// =======================================
// GET LOGGED-IN PATIENT'S APPOINTMENTS
// Patient only
// =======================================

const getMyAppointments = async (req, res) => {
    try {
        const patientId = req.user.id;

        const appointments =
            await getPatientAppointments(
                patientId
            );

        return res.status(200).json({
            success: true,
            count: appointments.length,
            appointments
        });

    } catch (err) {
        console.error(
            "Get My Appointments Error:",
            err
        );

        return res.status(500).json({
            success: false,
            message:
                "Internal Server Error"
        });
    }
};


// =======================================
// GET LOGGED-IN DOCTOR'S APPOINTMENTS
// Doctor only
// =======================================

const getMyDoctorAppointments = async (
    req,
    res
) => {
    try {
        // req.user.id is the USER ID
        // The model connects it to doctors.user_id
        const doctorUserId = req.user.id;

        const appointments =
            await getDoctorAppointments(
                doctorUserId
            );

        return res.status(200).json({
            success: true,
            count: appointments.length,
            appointments
        });

    } catch (err) {
        console.error(
            "Get Doctor Appointments Error:",
            err
        );

        return res.status(500).json({
            success: false,
            message:
                "Internal Server Error"
        });
    }
};


// =======================================
// GET APPOINTMENT BY ID
// =======================================

const getAppointment = async (req, res) => {
    try {
        const appointmentId =
            Number(req.params.id);

        const appointment =
            await getAppointmentById(
                appointmentId
            );

        if (!appointment) {
            return res.status(404).json({
                success: false,
                message:
                    "Appointment not found."
            });
        }

        // ===================================
        // ADMIN
        // ===================================

        if (req.user.role === "admin") {
            return res.status(200).json({
                success: true,
                appointment
            });
        }

        // ===================================
        // PATIENT
        // ===================================

        if (req.user.role === "patient") {

            if (
                appointment.patient_id !==
                req.user.id
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You are not authorized to view this appointment."
                });
            }

            return res.status(200).json({
                success: true,
                appointment
            });
        }

        // ===================================
        // DOCTOR
        // ===================================

        if (req.user.role === "doctor") {

            const doctorAppointments =
                await getDoctorAppointments(
                    req.user.id
                );

            const ownsAppointment =
                doctorAppointments.some(
                    (item) =>
                        item.id ===
                        appointmentId
                );

            if (!ownsAppointment) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You are not authorized to view this appointment."
                });
            }

            return res.status(200).json({
                success: true,
                appointment
            });
        }

        return res.status(403).json({
            success: false,
            message:
                "You are not authorized to view this appointment."
        });

    } catch (err) {
        console.error(
            "Get Appointment Error:",
            err
        );

        return res.status(500).json({
            success: false,
            message:
                "Internal Server Error"
        });
    }
};


// =======================================
// UPDATE APPOINTMENT
// Patient / Doctor / Admin
// =======================================

const editAppointment = async (req, res) => {
    try {

        const appointmentId =
            Number(req.params.id);

        // Find existing appointment
        const existingAppointment =
            await getAppointmentById(
                appointmentId
            );

        if (!existingAppointment) {
            return res.status(404).json({
                success: false,
                message:
                    "Appointment not found."
            });
        }

        // ===================================
        // PATIENT OWNERSHIP
        // ===================================

        if (req.user.role === "patient") {

            if (
                existingAppointment.patient_id !==
                req.user.id
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You can only update your own appointments."
                });
            }
        }

        // ===================================
        // DOCTOR OWNERSHIP
        // ===================================

        if (req.user.role === "doctor") {

            const doctorAppointments =
                await getDoctorAppointments(
                    req.user.id
                );

            const ownsAppointment =
                doctorAppointments.some(
                    (item) =>
                        item.id ===
                        appointmentId
                );

            if (!ownsAppointment) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You can only update your own appointments."
                });
            }
        }

        // ===================================
        // VALIDATE STATUS
        // ===================================

        const allowedStatuses = [
            "scheduled",
            "completed",
            "cancelled"
        ];

        if (
            req.body.status &&
            !allowedStatuses.includes(
                req.body.status
            )
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Invalid appointment status."
            });
        }

        // ===================================
        // DOCTOR STATUS UPDATE
        // ===================================

        /*
         * Doctors use the dashboard to:
         *
         * 1. Complete appointments
         * 2. Cancel appointments
         *
         * The doctor does not need to change
         * patient/date/time information.
         */

        let appointmentData;

        if (req.user.role === "doctor") {

            appointmentData = {
                appointment_date:
                    existingAppointment.appointment_date,

                start_time:
                    existingAppointment.start_time,

                end_time:
                    existingAppointment.end_time,

                status:
                    req.body.status ||
                    existingAppointment.status,

                notes:
                    existingAppointment.notes
            };

        } else {

            // Patient/Admin can update
            // appointment details

            appointmentData = {
                appointment_date:
                    req.body.appointment_date ||
                    existingAppointment.appointment_date,

                start_time:
                    req.body.start_time ||
                    existingAppointment.start_time,

                end_time:
                    req.body.end_time ||
                    existingAppointment.end_time,

                status:
                    req.body.status ||
                    existingAppointment.status,

                notes:
                    req.body.notes ??
                    existingAppointment.notes
            };
        }

        // ===================================
        // UPDATE DATABASE
        // ===================================

        const result =
            await updateAppointment(
                appointmentId,
                appointmentData
            );

        if (result.changes === 0) {
            return res.status(400).json({
                success: false,
                message:
                    "No changes were made."
            });
        }

        return res.status(200).json({
            success: true,
            message:
                "Appointment updated successfully."
        });

    } catch (err) {
        console.error(
            "Update Appointment Error:",
            err
        );

        return res.status(500).json({
            success: false,
            message:
                "Internal Server Error"
        });
    }
};


// =======================================
// DELETE / CANCEL APPOINTMENT
// =======================================

const removeAppointment = async (
    req,
    res
) => {
    try {

        const appointmentId =
            Number(req.params.id);

        const appointment =
            await getAppointmentById(
                appointmentId
            );

        if (!appointment) {
            return res.status(404).json({
                success: false,
                message:
                    "Appointment not found."
            });
        }

        // ===================================
        // PATIENT OWNERSHIP
        // ===================================

        if (req.user.role === "patient") {

            if (
                appointment.patient_id !==
                req.user.id
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You can only cancel your own appointments."
                });
            }
        }

        // ===================================
        // DOCTOR OWNERSHIP
        // ===================================

        if (req.user.role === "doctor") {

            const doctorAppointments =
                await getDoctorAppointments(
                    req.user.id
                );

            const ownsAppointment =
                doctorAppointments.some(
                    (item) =>
                        item.id ===
                        appointmentId
                );

            if (!ownsAppointment) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You can only cancel your own appointments."
                });
            }
        }

        // ===================================
        // DELETE
        // ===================================

        const result =
            await deleteAppointment(
                appointmentId
            );

        if (result.changes === 0) {
            return res.status(404).json({
                success: false,
                message:
                    "Appointment could not be deleted."
            });
        }

        return res.status(200).json({
            success: true,
            message:
                "Appointment cancelled successfully."
        });

    } catch (err) {
        console.error(
            "Delete Appointment Error:",
            err
        );

        return res.status(500).json({
            success: false,
            message:
                "Internal Server Error"
        });
    }
};


// =======================================
// EXPORT CONTROLLERS
// =======================================

module.exports = {
    bookAppointment,
    getAppointments,
    getMyAppointments,
    getMyDoctorAppointments,
    getAppointment,
    editAppointment,
    removeAppointment
};