import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "../pages/Home/Home";
import Login from "../pages/Login/Login";
import Register from "../pages/Register/Register";
import ForgotPassword from "../pages/ForgotPassword/ForgotPassword";

import PatientDashboard from "../pages/Patient/PatientDashboard";
import DoctorDashboard from "../pages/Doctor/DoctorDashboard";
import AdminDashboard from "../pages/Admin/AdminDashboard";

/* Doctor Components */
import DoctorAppointments from "../components/Doctor/DoctorAppointments";
import TodayAppointments from "../components/Doctor/TodayAppointments";
import Availability from "../components/Doctor/Availability";
import DoctorProfile from "../components/Doctor/DoctorProfile";

import NotFound from "../pages/NotFound/NotFound";

import ProtectedRoute from "./ProtectedRoute";

function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>

        {/* ===================================== */}
        {/* PUBLIC ROUTES */}
        {/* ===================================== */}

        <Route
          path="/"
          element={<Home />}
        />

        <Route
          path="/login"
          element={<Login />}
        />

        <Route
          path="/register"
          element={<Register />}
        />

        <Route
          path="/forgot-password"
          element={<ForgotPassword />}
        />


        {/* ===================================== */}
        {/* PATIENT ROUTES */}
        {/* ===================================== */}

        <Route
          path="/patient"
          element={
            <ProtectedRoute role="patient">
              <PatientDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/patient/book-appointment"
          element={
            <ProtectedRoute role="patient">
              <PatientDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/patient/appointments"
          element={
            <ProtectedRoute role="patient">
              <PatientDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/patient/doctors"
          element={
            <ProtectedRoute role="patient">
              <PatientDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/patient/profile"
          element={
            <ProtectedRoute role="patient">
              <PatientDashboard />
            </ProtectedRoute>
          }
        />


        {/* ===================================== */}
        {/* DOCTOR DASHBOARD */}
        {/* ===================================== */}

        <Route
          path="/doctor"
          element={
            <ProtectedRoute role="doctor">
              <DoctorDashboard />
            </ProtectedRoute>
          }
        />


        {/* ===================================== */}
        {/* DOCTOR - ALL APPOINTMENTS */}
        {/* ===================================== */}

        <Route
          path="/doctor/appointments"
          element={
            <ProtectedRoute role="doctor">
              <DoctorAppointments />
            </ProtectedRoute>
          }
        />


        {/* ===================================== */}
        {/* DOCTOR - TODAY'S APPOINTMENTS */}
        {/* ===================================== */}

        <Route
          path="/doctor/today"
          element={
            <ProtectedRoute role="doctor">
              <TodayAppointments />
            </ProtectedRoute>
          }
        />


        {/* ===================================== */}
        {/* DOCTOR - AVAILABILITY */}
        {/* ===================================== */}

        <Route
          path="/doctor/availability"
          element={
            <ProtectedRoute role="doctor">
              <Availability />
            </ProtectedRoute>
          }
        />


        {/* ===================================== */}
        {/* DOCTOR - PROFILE */}
        {/* ===================================== */}

        <Route
          path="/doctor/profile"
          element={
            <ProtectedRoute role="doctor">
              <DoctorProfile />
            </ProtectedRoute>
          }
        />


        {/* ===================================== */}
        {/* ADMIN DASHBOARD */}
        {/* ===================================== */}

        <Route
          path="/admin"
          element={
            <ProtectedRoute role="admin">
              <AdminDashboard />
            </ProtectedRoute>
          }
        />


        {/* ===================================== */}
        {/* 404 */}
        {/* ===================================== */}

        <Route
          path="*"
          element={<NotFound />}
        />

      </Routes>
    </BrowserRouter>
  );
}

export default AppRoutes;