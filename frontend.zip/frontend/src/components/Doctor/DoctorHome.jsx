import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../../services/api";
import "./Doctors.css";

function Doctors() {
  const navigate = useNavigate();

  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedDoctorId, setSelectedDoctorId] = useState(null);

  useEffect(() => {
    fetchDoctors();
  }, []);

  const getDoctorId = (doctor) => {
    const id = doctor?.doctor_id ?? doctor?.id;
    const numericId = Number(id);

    return Number.isFinite(numericId) && numericId > 0
      ? numericId
      : null;
  };

  const fetchDoctors = async () => {
    try {
      setLoading(true);
      setError("");

      const res = await API.get("/doctors");

      console.log("Doctors Response:", res.data);

      setDoctors(Array.isArray(res.data?.doctors) ? res.data.doctors : []);
    } catch (err) {
      console.error("Doctors Error:", err);

      setDoctors([]);

      setError(
        err.response?.data?.message ||
          "Unable to load doctors. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleBook = (doctor) => {
    const doctorId = getDoctorId(doctor);

    if (!doctorId) {
      alert("Doctor ID is missing.");
      return;
    }

    console.log("Selected Doctor ID:", doctorId);

    setSelectedDoctorId(doctorId);

    navigate("/patient/book-appointment", {
      state: {
        doctorId: doctorId,
      },
    });
  };

  const handleDashboard = () => {
    navigate("/patient");
  };

  if (loading) {
    return (
      <div className="doctors-page">
        <div className="page-header">
          <div>
            <h2>👨‍⚕️ Our Doctors</h2>
            <p>Find a doctor and book an appointment.</p>
          </div>

          <button
            className="dashboard-btn"
            onClick={handleDashboard}
          >
            🏠 Dashboard
          </button>
        </div>

        <div className="empty-state">
          <h3>Loading doctors...</h3>
          <p>Please wait.</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="doctors-page">
        <div className="page-header">
          <div>
            <h2>👨‍⚕️ Our Doctors</h2>
            <p>Find a doctor and book an appointment.</p>
          </div>

          <button
            className="dashboard-btn"
            onClick={handleDashboard}
          >
            🏠 Dashboard
          </button>
        </div>

        <div className="empty-state">
          <h3>Unable to load doctors</h3>
          <p>{error}</p>

          <button className="retry-btn" onClick={fetchDoctors}>
            🔄 Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="doctors-page">
      <div className="page-header">
        <div>
          <h2>👨‍⚕️ Our Doctors</h2>
          <p>Choose a doctor and book your appointment.</p>
        </div>

        <button
          className="dashboard-btn"
          onClick={handleDashboard}
        >
          🏠 Dashboard
        </button>
      </div>

      {doctors.length === 0 ? (
        <div className="empty-state">
          <h3>No doctors available</h3>
          <p>There are currently no doctors registered.</p>
        </div>
      ) : (
        <div className="doctor-grid">
          {doctors.map((doctor, index) => {
            const doctorId = getDoctorId(doctor);

            return (
              <div
                className="doctor-card"
                key={doctorId || doctor.email || doctor.name || index}
              >
                <div className="doctor-avatar">👨‍⚕️</div>

                <h3>
                  {doctor.name || "Doctor"}
                </h3>

                <p>
                  <strong>Specialization:</strong>{" "}
                  {doctor.specialization || "General"}
                </p>

                {doctor.email && (
                  <p>
                    <strong>Email:</strong>{" "}
                    {doctor.email}
                  </p>
                )}

                {doctor.phone && (
                  <p>
                    <strong>Phone:</strong>{" "}
                    {doctor.phone}
                  </p>
                )}

                <p>
                  Experienced medical professional available
                  for appointments.
                </p>

                <button
                  className="book-btn"
                  onClick={() => handleBook(doctor)}
                  disabled={!doctorId || selectedDoctorId === doctorId}
                >
                  {selectedDoctorId === doctorId
                    ? "Opening..."
                    : "📅 Book Appointment"}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default Doctors;