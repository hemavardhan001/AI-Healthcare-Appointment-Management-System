import { useNavigate, useLocation } from "react-router-dom";

import DoctorHome from "../../components/Doctor/DoctorHome";
import TodayAppointments from "../../components/Doctor/TodayAppointments";
import Availability from "../../components/Doctor/Availability";
import DoctorProfile from "../../components/Doctor/DoctorProfile";

import "./DoctorDashboard.css";

function DoctorDashboard() {
  const navigate = useNavigate();
  const location = useLocation();

  const user = JSON.parse(localStorage.getItem("user") || "{}");
  const doctorName = user?.name || "Doctor";

  const currentPath = location.pathname;

  const goTo = (path) => {
    navigate(path);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("user");
    localStorage.removeItem("userId");
    localStorage.removeItem("userName");

    navigate("/login");
  };

  const renderPage = () => {
    switch (currentPath) {
      case "/doctor/today":
        return <TodayAppointments />;

      case "/doctor/availability":
        return <Availability />;

      case "/doctor/profile":
        return <DoctorProfile />;

      case "/doctor":
      default:
        return <DoctorHome />;
    }
  };

  return (
    <div className="dashboard">
      {/* Sidebar */}
      <aside className="sidebar">
        <h2>👨‍⚕️ Doctor Panel</h2>

        <ul>
          <li
            className={currentPath === "/doctor" ? "active" : ""}
            onClick={() => goTo("/doctor")}
          >
            🏠 Dashboard
          </li>

          <li
            className={currentPath === "/doctor/today" ? "active" : ""}
            onClick={() => goTo("/doctor/today")}
          >
            📅 Today's Appointments
          </li>

          <li
            className={currentPath === "/doctor/availability" ? "active" : ""}
            onClick={() => goTo("/doctor/availability")}
          >
            ⏰ Availability
          </li>

          <li
            className={currentPath === "/doctor/profile" ? "active" : ""}
            onClick={() => goTo("/doctor/profile")}
          >
            👤 Profile
          </li>
        </ul>

        <button onClick={handleLogout}>🚪 Logout</button>
      </aside>

      {/* Main Content */}
      <main className="content">
        <div className="welcome-card">
          <h1>Welcome Dr. {doctorName} 👋</h1>
          <p>Manage appointments and your availability.</p>
        </div>

        <div style={{ marginTop: "30px" }}>
          {renderPage()}
        </div>
      </main>
    </div>
  );
}

export default DoctorDashboard;